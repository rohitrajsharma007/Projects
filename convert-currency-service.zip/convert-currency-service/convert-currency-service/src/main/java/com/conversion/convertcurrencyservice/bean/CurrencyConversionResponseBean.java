package com.conversion.convertcurrencyservice.bean;

import java.math.BigDecimal;

public class CurrencyConversionResponseBean {

	
	private String port;
	private BigDecimal amount;
	private String conversionMultiple;
	private BigDecimal totalCalculatedAmount;


	 public CurrencyConversionResponseBean() {

	  }

	  
	  public CurrencyConversionResponseBean(BigDecimal amount,String conversionMultiple,BigDecimal totalCalculatedAmount,String port) {
	    super();
	    this.amount = amount;
	    this.conversionMultiple = conversionMultiple;
	    this.totalCalculatedAmount = totalCalculatedAmount;
	    this.port = port;
	  }

		  public String getConversionMultiple() {
           return conversionMultiple;
          }

     public void setConversionMultiple(String conversionMultiple) {
         this.conversionMultiple = conversionMultiple;
     }

  public BigDecimal getTotalCalculatedAmount() {
    return totalCalculatedAmount;
  }

  public void setTotalCalculatedAmount(BigDecimal totalCalculatedAmount) {
    this.totalCalculatedAmount = totalCalculatedAmount;
  }

  public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

  public String getPort() {
	return port;
}

public void setPort(String port) {
	this.port = port;
}

}
