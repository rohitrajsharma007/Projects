package com.conversion.convertcurrencyservice.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.conversion.convertcurrencyservice.bean.ConversionBean;
import com.conversion.convertcurrencyservice.bean.CurrencyConvRequestBean;
import com.conversion.convertcurrencyservice.bean.CurrencyConversionResponseBean;
import com.conversion.convertcurrencyservice.service.CurrencyExchangeService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@RestController
public class CurrencyConversionController {

	@Autowired
	  private CurrencyExchangeService currExch;

	  @PostMapping("/convert-Currency")
	  @HystrixCommand(fallbackMethod = "defaultCurrency")
	  public BigDecimal convertCurrency(@RequestBody CurrencyConvRequestBean currBean) {
		  String response = null;
	  
		try {  
	    ResponseEntity<String> responseEntity = new RestTemplate().getForEntity(
		        "http://localhost:8010/currency-exchange/{countryCode}", String.class,currBean.getCountryCode());

		     response = responseEntity.getBody();
		}catch(Exception exc) {
			exc.printStackTrace();
			throw new RuntimeException();
		}
	    return currBean.getAmount().multiply(new BigDecimal(Double.valueOf(response)));
	  }


	  @PostMapping("/currency-converter-feign")
	  @HystrixCommand(fallbackMethod = "defaultCurrencyFeign")
	  public CurrencyConversionResponseBean convertCurrencyFeign(@RequestBody CurrencyConvRequestBean currBean) {	
//	  public BigDecimal convertCurrencyFeign(@RequestBody CurrencyConvRequestBean currBean) {
		   
		  try {
			  ConversionBean response = currExch.retrieveExchangeValue(currBean.getCountryCode());
	//		  String response = currExch.retrieveExchangeValue(currBean.getCountryCode());
	System.out.println("response::"+response);		  
			  
			  BigDecimal totalAmt =   currBean.getAmount().multiply(response.getConversionFactor());
		  return new CurrencyConversionResponseBean(currBean.getAmount(),String.valueOf(response.getConversionFactor()), totalAmt,String.valueOf(response.getPort()));
	//    return currBean.getAmount().multiply(new BigDecimal(Double.valueOf(response)));
	  }catch(Exception ex) {
		  ex.printStackTrace();	
			throw new RuntimeException();
	  }
		
	  }
	  
	  /**
	   * Circuit breaker method 
	   * @param currBean
	   * @return
	   */
	  public CurrencyConversionResponseBean defaultCurrencyFeign(@RequestBody CurrencyConvRequestBean currBean) {	
		 
		  System.out.println("Feign call Curency service failed" ); 
		  
		  BigDecimal totalAmt =   currBean.getAmount().multiply(new BigDecimal(10.00));
		return new CurrencyConversionResponseBean(currBean.getAmount(),"10.00", totalAmt,"localhost");
	  }
	  
	  /**
	   * Circuit breaker method for REST call failure
	   * @param currBean
	   * @return
	   */
	  public BigDecimal defaultCurrency(@RequestBody CurrencyConvRequestBean currBean) {

		  System.out.println(" Curency REST call service failed" );
		  return currBean.getAmount().multiply(new BigDecimal(5.00));
	  }

}
