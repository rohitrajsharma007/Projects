package com.conversion.convertcurrencyservice.service;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.conversion.convertcurrencyservice.bean.ConversionBean;


//@FeignClient(name="manage-currency-service", url="localhost:8010")

@FeignClient(name="manage-currency-service")
@RibbonClient(name="manage-currency-service")		
public interface CurrencyExchangeService {
	
	 @GetMapping("/currency-exchange/{countryCode}")
	  public ConversionBean retrieveExchangeValue(@PathVariable("countryCode") String countryCode);
	// public String retrieveExchangeValue(@PathVariable("countryCode") String countryCode);
	
}
