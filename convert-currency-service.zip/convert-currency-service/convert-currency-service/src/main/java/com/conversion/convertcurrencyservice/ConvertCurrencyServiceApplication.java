package com.conversion.convertcurrencyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.conversion.convertcurrencyservice")
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableHystrix

public class ConvertCurrencyServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvertCurrencyServiceApplication.class, args);
	}

}
