package com.conversion.convertcurrencyservice.bean;

import java.math.BigDecimal;


public class ConversionBean {

	private String countryCode;

	private BigDecimal conversionFactor;
	
	
	private int port;

	public ConversionBean() {
		
	}
	public ConversionBean(String countryCode, BigDecimal conversionFactor) {
		super();
		this.countryCode = countryCode;
		this.conversionFactor = conversionFactor;
	}
	
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public BigDecimal getConversionFactor() {
		return conversionFactor;
	}
	public void setConversionFactor(BigDecimal conversionFactor) {
		this.conversionFactor = conversionFactor;
	}

	@Override
	public String toString() {
		return "ConversionBean [countryCode=" + countryCode + ", conversionFactor=" + conversionFactor + "]";
	}

	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
}
