package com.conversion.convertcurrencyservice.bean;

import java.math.BigDecimal;

public class CurrencyConvRequestBean {
	  
	private BigDecimal amount;
	
	private String countryCode;
	
	 public CurrencyConvRequestBean() {

	  }

	  
	  public CurrencyConvRequestBean(String countrycode,BigDecimal amount) {
	    super();
	    this.amount = amount;
	    this.countryCode = countrycode;
	  }


	    public BigDecimal getAmount() {
			return amount;
		}

		public void setAmount(BigDecimal amount) {
			this.amount = amount;
		}


		public String getCountryCode() {
			return countryCode;
		}


		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}

		@Override
		public String toString() {
			return "CurrencyConversionBean [amount=" + amount + ", countryCode=" + countryCode + "]";
		}
		
//		@Override
//		public String toString() {
//			return "CurrencyConversionBean [amount=" + amount + ", countryCode=" + countryCode + ", conversionMultiple="
//					+ conversionMultiple + ", totalCalculatedAmount=" + totalCalculatedAmount + "]";
//		}

}
