package com.ibm.token.issuer.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ibm.token.issuer.model.RequestData;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.util.X509CertUtils;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

//
@Service
public class TokenService {

	private final Logger LOG = LoggerFactory.getLogger(TokenService.class);

	@Value("${token.issuer.url}")
	private String issuer;

	@Value("${token.issuer.pkcs12}")
	private String serverPKCS;

	@Value("${service.provider.x509}")
	private String clientCertificate;

	private RSAKey getPublicKey(String certificateFile) {
		RSAKey publicKey = null;
		try {
			String fileContent = new String(Files.readAllBytes(Paths.get(certificateFile)));
			X509Certificate certificate = X509CertUtils.parse(fileContent);
			publicKey = RSAKey.parse(certificate);
			LOG.info("Public key was fetched from the certificate");
		} catch (IOException | JOSEException e) {
			LOG.error(e.toString());
		}
		return publicKey;
	}

	private RSAKey getJSONWebKey(String pkcsFile) {
		RSAKey jwk = null;
		try {
			KeyStore keyStore = KeyStore.getInstance("PKCS12");
			FileInputStream pkcs = new FileInputStream(pkcsFile);
			keyStore.load(pkcs, "".toCharArray());
			Enumeration aliases = keyStore.aliases();
			while (aliases.hasMoreElements()) {
				String alias = (String) aliases.nextElement();
				RSAPrivateKey privateKey = (RSAPrivateKey) keyStore.getKey(alias, "".toCharArray());
				X509Certificate certificate = (X509Certificate) keyStore.getCertificate(alias);
				RSAKey publicKey = RSAKey.parse(certificate);
				jwk = new RSAKey.Builder(publicKey).privateKey(privateKey).build();
				break;
			}
		} catch (IOException | KeyStoreException | JOSEException | NoSuchAlgorithmException | UnrecoverableKeyException
				| CertificateException ex) {
			LOG.error(ex.toString());
		}
		return jwk;
	}

	public String getToken(RequestData requestData) {
		String token = "unknown";
		try {
			String userToken = requestData.getUserToken();
			String userName = requestData.getUserName();
			String userEmail = requestData.getUserEmailId();
			String subject = requestData.getSubject();
			String orderId = requestData.getOrderId();
			String orderName = requestData.getOrderName();
			LOG.info("userToken" + userToken + " orderId = " + orderId + ", orderName = " + orderName + ", subject = "
					+ subject);

			RSAKey serverJWK = getJSONWebKey(serverPKCS);

			JWSHeader jwtHeader = new JWSHeader.Builder(JWSAlgorithm.RS256).jwk(serverJWK).build();
			Calendar now = Calendar.getInstance();
			Date issueTime = now.getTime();
			now.add(Calendar.MINUTE, 10);
			Date expiryTime = now.getTime();
			String jti = String.valueOf(issueTime.getTime());

			// Date expiryTime = issueTime.
			JWTClaimsSet jwtClaims = new JWTClaimsSet.Builder().issuer(issuer).subject(subject).issueTime(issueTime)
					.expirationTime(expiryTime).claim("orderId", orderId).claim("orderName", orderName).jwtID(jti)
					.build();
			LOG.info("JWT claims = " + jwtClaims.toString());
			SignedJWT jws = new SignedJWT(jwtHeader, jwtClaims);
			RSASSASigner signer = new RSASSASigner(serverJWK);
			jws.sign(signer);

			JWEHeader jweHeader = new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM)
					.contentType("JWT").build();

			JWEObject jwe = new JWEObject(jweHeader, new Payload(jws));

			// Encrypt with the recipient's public key
			RSAKey clientPublicKey = getPublicKey(clientCertificate);

			jwe.encrypt(new RSAEncrypter(clientPublicKey));

			token = jwe.serialize();
			LOG.info("Token = " + token);

			RequestData userDetails = new RequestData();
			userDetails.setUserToken(userToken);
			userDetails.setOrderId(orderId);
			userDetails.setOrderName(orderName);
			userDetails.setUserName(userName);
			userDetails.setUserEmailId(userEmail);
			save(userDetails);

		} catch (final JOSEException e) {
			// TODO Auto-generated catch block
			LOG.error(e.toString());
		}
		return token;
	}

	public void save(RequestData userDetails) {

		Connection conn = null;
		Statement stmt = null;
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (Exception e) {
				System.out.println(e);
			}

			conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase?useSSL=false",
					"root", "admin1234");
			String sql = "INSERT INTO USERDETAILS VALUES(?,?,?,?,?)";

			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, userDetails.getUserToken());
			pst.setString(2, userDetails.getUserName());
			pst.setString(3, userDetails.getUserEmailId());
			pst.setString(4, userDetails.getOrderId());
			pst.setString(5, userDetails.getOrderName());

			pst.executeUpdate();

		} catch (SQLException excep) {
			excep.printStackTrace();
		} catch (Exception excep) {
			excep.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					conn.close();
			} catch (SQLException se) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}

}
