package com.ibm.service.provider.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.ibm.service.provider.service.TokenValidator;

@Controller
public class HomePageController {

	@Autowired
	TokenValidator tokenValidator;

	private final Logger LOG = LoggerFactory.getLogger(HomePageController.class);

	//Once token validation Complete show Order Id and Order Name
	
	@GetMapping("/")
	public ResponseEntity<?> index(HttpServletRequest request) {

		String output = ("<html><head><title>Order Provider</title></head>"
				+ "<body><h1>Error</h1><p style=\"color:blue;\">Invalid token</p></body></html>");
		if (tokenValidator.isValid(request)) {
			String OrderId = ("Order Id " + tokenValidator.getOrderId());
			String OrderName = ("Order Name # " + tokenValidator.getOrderName());
			output = output.replaceAll("Error", " <p style=\\\"color:blue;\\\">Order confirm  successfully </p>")
					.replaceAll("Invalid token", OrderId + "</p><p>" + OrderName);
		}
		return (new ResponseEntity<>(output, HttpStatus.OK));
	}
}