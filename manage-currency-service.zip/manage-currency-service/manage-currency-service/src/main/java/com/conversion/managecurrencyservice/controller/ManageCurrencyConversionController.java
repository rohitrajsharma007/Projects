package com.conversion.managecurrencyservice.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.conversion.managecurrencyservice.bean.ConversionBean;
import com.conversion.managecurrencyservice.bean.ResponseStatus;
import com.conversion.managecurrencyservice.entity.Conversion;
import com.conversion.managecurrencyservice.service.ConversionRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@RestController
public class ManageCurrencyConversionController {

	@Autowired
	private ConversionRepository convRep;

	@Autowired
	private Environment env;
	
	
	@PostMapping("/conversion-exchange")
	@HystrixCommand(fallbackMethod="defaultConversion")
	public ResponseStatus addConversionFactor(@RequestBody Conversion convVO){
		
		try {
     		convRep.save(convVO);
     		
	    	return new ResponseStatus("200","Addition Executed Successfully");
		}catch(Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException();
		//	return new ResponseStatus("404","Failed");		
	    }	
	}
	
	
	@PutMapping("/currency-update")
	//@HystrixCommand(fallbackMethod="defaultConversion")
	//public ResponseEntity<Object> updateConversionFactor(@PathVariable String countryCode,@PathVariable BigDecimal conversionFactor){
	public ResponseStatus updateConversionFactor(@RequestBody Conversion convVO){
		try {
     		 convRep.save(convVO);
	    	return new ResponseStatus("200","Updation Executed Successfully");
		}catch(Exception ex) {
		   ex.printStackTrace();
			return new ResponseStatus("404","Updation Failed due to"+ex.getMessage());		
	    }
	}
	
	@GetMapping("/currency-exchange/{countryCode}")
	@HystrixCommand(fallbackMethod="backConversion")
//	public String getConversionFactor(@PathVariable String countryCode){
	public ConversionBean getConversionFactor(@PathVariable String countryCode){	
	
	List<Conversion>convList = convRep.findByCountryCode(countryCode);
	System.out.println("List size: "+convList.size());
	
	Conversion conv = convList.get(0);
	ConversionBean bean = new ConversionBean(conv.getCountryCode(),conv.getConversionFactor(),Integer.parseInt(env.getProperty("local.server.port")));
	//conv.setPort();
	
	//	return String.valueOf(conv.getConversionFactor());
	return bean;
	}
	
//    public ResponseStatus defaultConversion(@RequestBody Conversion conv){
    public ResponseStatus defaultConversion(@RequestBody Conversion convVO){
    	 convVO = new Conversion("IND", new BigDecimal("50.0"));
    	 System.out.println("Manage currency service is down, add/update failed ");	
    	convRep.save(convVO);	
    	return new ResponseStatus("100","Default value added");		
	}
    
//    public ConversionBean backConversion(@RequestBody Conversion convVO){	
    public ConversionBean backConversion(@PathVariable String countryCode){	
    	System.out.println("Manage currency service is down, fetch failed ");
    	ConversionBean bean = new ConversionBean("IND",new BigDecimal("50.0"),Integer.parseInt(env.getProperty("local.server.port")));
    	
    	return bean;
    }
    

}
