package com.conversion.managecurrencyservice.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.conversion.managecurrencyservice.entity.Conversion;

public interface ConversionRepository extends JpaRepository<Conversion, String> {

    public List<Conversion> findByCountryCode(String countrycode);
    
    public Conversion save(Conversion conv);
		
}
