package com.conversion.managecurrencyservice.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Conversion {
    @Id
	@Column(name="country_code")
	private String countryCode;

	@Column(name="conversion_factor")
	private BigDecimal conversionFactor;
	
	

	public Conversion() {
		
	}
	public Conversion(String countryCode, BigDecimal conversionFactor) {
		super();
		this.countryCode = countryCode;
		this.conversionFactor = conversionFactor;
	}
	
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public BigDecimal getConversionFactor() {
		return conversionFactor;
	}
	public void setConversionFactor(BigDecimal conversionFactor) {
		this.conversionFactor = conversionFactor;
	}

	@Override
	public String toString() {
		return "ConversionBean [countryCode=" + countryCode + ", conversionFactor=" + conversionFactor + "]";
	}
}
