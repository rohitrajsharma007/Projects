package com.conversion.managecurrencyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageCurrencyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
