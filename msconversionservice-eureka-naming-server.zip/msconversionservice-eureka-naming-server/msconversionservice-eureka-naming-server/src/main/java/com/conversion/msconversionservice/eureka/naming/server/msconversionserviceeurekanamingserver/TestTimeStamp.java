package com.conversion.msconversionservice.eureka.naming.server.msconversionserviceeurekanamingserver;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;

public class TestTimeStamp {

	public static void main(String[] args) {
		
		
		String timestampString = "1570014324";
        String systIme = String.valueOf(System.currentTimeMillis());
        
        Timestamp convTS = getTimestamp(systIme);
        System.out.println("Converted:"+convTS);
	
}
	public static Timestamp getTimestamp(String timestampInString) {
        if (StringUtils.isNotBlank(timestampInString) && timestampInString != null) {
            Date date = new Date(Long.parseLong(timestampInString));
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            format.setTimeZone(TimeZone.getTimeZone("Etc/UTC"));
            String formatted = format.format(date);
            Timestamp timeStamp = Timestamp.valueOf(formatted);
            
            return timeStamp;
        } else {
            return null;
        }
    }
}