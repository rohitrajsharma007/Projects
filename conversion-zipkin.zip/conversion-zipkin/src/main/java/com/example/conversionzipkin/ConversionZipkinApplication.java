package com.example.conversionzipkin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversionZipkinApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversionZipkinApplication.class, args);
	}

}
